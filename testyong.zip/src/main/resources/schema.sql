CREATE TABLE account (
    username VARCHAR2(128) NOT NULL,
    password VARCHAR2(256) NOT NULL,
    two_factor_secret VARCHAR2(256) NOT NULL,
    two_factor_enabled NUMBER(1) NOT NULL,
    PRIMARY KEY (username)
);
